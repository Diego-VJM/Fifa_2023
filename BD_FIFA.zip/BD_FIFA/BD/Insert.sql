INSERT INTO Habilidades (idHabilidad, nombre, descripcion)
				VALUES (1, "kamekameha", "Una habilidad muy poderosa");
INSERT INTO Jugadores (idJugador, usuario, nombre, apellido, contraseña, monedas)
                    VALUES (1, "Lol305", "Diego", "vega", "12345678vega", 0);