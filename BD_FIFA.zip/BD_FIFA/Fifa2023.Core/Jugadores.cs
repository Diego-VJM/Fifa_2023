
namespace Fifa2023.Core;

public class Jugadores
{
    public sbyte IdJugador { get; set; }
    public string? Usuario {get; set;}
    public string? Nombre {get; set;}
    public string? Apellido {get; set;}
    public string? Contrasena {get; set;}
    public int Monedas { get; set; }
}