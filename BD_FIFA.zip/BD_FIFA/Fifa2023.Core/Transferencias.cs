
namespace Fifa2023.Core;

public class Transferencias
{
    public int IdTransferencia;
    public int IdVendedor;
    public int IdComprador;
    public int IdFutbolista;
    public DateOnly Fecha;
    public float Precio;
    public bool Transferencia_exitosa;
}
