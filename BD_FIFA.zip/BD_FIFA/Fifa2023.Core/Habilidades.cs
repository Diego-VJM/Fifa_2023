using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fifa2023.Core
{
    public class Habilidades
    {
        public sbyte IdHabilidad;

        public string? Nombre;

        public string? Descripcion;
    }
}