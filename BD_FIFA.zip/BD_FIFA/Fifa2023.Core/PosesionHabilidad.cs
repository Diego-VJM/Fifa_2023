namespace Fifa2023.Core;

public class PosesionHabilidad
{
    public short IdFutbolista;

    public sbyte IdHabilidad;
}
