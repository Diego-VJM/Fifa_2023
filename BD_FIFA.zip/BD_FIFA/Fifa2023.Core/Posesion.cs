using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fifa2023.Core
{
    public class Posesion
    {
        public Futbolistas? IdFutbolista;

        public Jugadores? IdJugador;

    }
}