using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fifa2023.Core
{
    public class Futbolistas
    {
    
    public sbyte IdFutbolista; 
    
    public Posiciones? IdPosicion;

    public string? Nombre;

    public string? Apellido;

    public DateOnly Nacimiento;

    public sbyte Velocidad;

    public sbyte Remate;

    public sbyte Pase;

    public sbyte Defensa;


    }
}